globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/OBK1Xh1Px_BH0BUlY7nfo/_buildManifest.js",
    "static/OBK1Xh1Px_BH0BUlY7nfo/_ssgManifest.js",
    "static/OBK1Xh1Px_BH0BUlY7nfo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0hpnrek~99o9g.js",
    "static/chunks/0gy8dglnb5e_x.js",
    "static/chunks/0yl257biw2tv8.js",
    "static/chunks/11pm9a-3v_iu3.js",
    "static/chunks/04.i-__.as.dk.js",
    "static/chunks/turbopack-0dp-jdtl5tl8c.js"
  ]
};
