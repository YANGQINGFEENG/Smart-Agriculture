var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/yolo-models/route.js")
R.c("server/chunks/[root-of-the-server]__0vhq_1l._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0qt6v09.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device_yolo-models_route_actions_10m1gzj.js")
R.m(427504)
module.exports=R.m(427504).exports
