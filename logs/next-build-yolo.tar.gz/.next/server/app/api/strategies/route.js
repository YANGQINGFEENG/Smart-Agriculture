var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/strategies/route.js")
R.c("server/chunks/[root-of-the-server]__0yeq_dg._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_strategies_route_actions_0csdj9s.js")
R.m(911251)
module.exports=R.m(911251).exports
