var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/strategies/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0x~3apm._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_strategies_[id]_route_actions_0f36i5z.js")
R.m(352648)
module.exports=R.m(352648).exports
