var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/strategies/execution-logs/route.js")
R.c("server/chunks/[root-of-the-server]__0q_glxt._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_strategies_execution-logs_route_actions_0.4flt8.js")
R.m(399473)
module.exports=R.m(399473).exports
