var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/websocket/route.js")
R.c("server/chunks/[root-of-the-server]__0~x3yzg._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_websocket_route_actions_0qzm3lo.js")
R.m(492339)
module.exports=R.m(492339).exports
