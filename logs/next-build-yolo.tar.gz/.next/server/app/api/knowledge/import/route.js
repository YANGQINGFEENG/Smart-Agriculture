var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/import/route.js")
R.c("server/chunks/[root-of-the-server]__0qrjf9g._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_import_route_actions_0704zqu.js")
R.m(120007)
module.exports=R.m(120007).exports
