var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/smart-add/route.js")
R.c("server/chunks/[externals]__0iel.dx._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0w3439t.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_smart-add_route_actions_0inqco2.js")
R.m(132806)
module.exports=R.m(132806).exports
