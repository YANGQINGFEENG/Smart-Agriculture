var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/search/route.js")
R.c("server/chunks/[root-of-the-server]__10vyz6b._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_search_route_actions_0m.8_j7.js")
R.m(759118)
module.exports=R.m(759118).exports
