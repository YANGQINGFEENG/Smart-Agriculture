var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/compare/route.js")
R.c("server/chunks/[root-of-the-server]__063zowi._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_compare_route_actions_0khrlxw.js")
R.m(564885)
module.exports=R.m(564885).exports
