var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/export/route.js")
R.c("server/chunks/[root-of-the-server]__094i0~7._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_export_route_actions_10jc0-f.js")
R.m(843717)
module.exports=R.m(843717).exports
