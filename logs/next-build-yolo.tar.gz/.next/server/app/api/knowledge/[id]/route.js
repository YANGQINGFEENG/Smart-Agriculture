var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0_ba_wt._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_[id]_route_actions_0mj9ani.js")
R.m(901309)
module.exports=R.m(901309).exports
