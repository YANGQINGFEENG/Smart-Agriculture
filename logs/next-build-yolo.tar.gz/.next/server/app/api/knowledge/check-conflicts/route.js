var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/check-conflicts/route.js")
R.c("server/chunks/[root-of-the-server]__0g_7as7._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_check-conflicts_route_actions_0xle4pz.js")
R.m(793389)
module.exports=R.m(793389).exports
