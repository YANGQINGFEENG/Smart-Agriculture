var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sensor-types/route.js")
R.c("server/chunks/[root-of-the-server]__0oj9t.p._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sensor-types_route_actions_0250656.js")
R.m(766630)
module.exports=R.m(766630).exports
