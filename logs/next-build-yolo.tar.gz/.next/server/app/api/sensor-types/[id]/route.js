var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sensor-types/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__07l-ol5._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sensor-types_[id]_route_actions_0v7_c8v.js")
R.m(461799)
module.exports=R.m(461799).exports
