var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/gateways/route.js")
R.c("server/chunks/[root-of-the-server]__097r7xe._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_gateways_route_actions_0z3ldgy.js")
R.m(228970)
module.exports=R.m(228970).exports
