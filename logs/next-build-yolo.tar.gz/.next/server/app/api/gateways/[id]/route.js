var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gateways/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0z-s8oi._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_gateways_[id]_route_actions_0ku8iu1.js")
R.m(377304)
module.exports=R.m(377304).exports
