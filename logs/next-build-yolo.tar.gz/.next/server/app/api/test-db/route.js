var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-db/route.js")
R.c("server/chunks/[root-of-the-server]__0ryy_m-._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_test-db_route_actions_0y60t1y.js")
R.m(815863)
module.exports=R.m(815863).exports
