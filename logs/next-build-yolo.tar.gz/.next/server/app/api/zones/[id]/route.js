var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/zones/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__02~-0z8._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_zones_[id]_route_actions_0o4zu7m.js")
R.m(434072)
module.exports=R.m(434072).exports
