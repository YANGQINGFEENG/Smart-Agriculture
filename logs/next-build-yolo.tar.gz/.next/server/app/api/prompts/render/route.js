var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/prompts/render/route.js")
R.c("server/chunks/[root-of-the-server]__12whx8i._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_prompts_render_route_actions_11ck.fs.js")
R.m(14057)
module.exports=R.m(14057).exports
