var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/prompts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0-f.6i~._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_prompts_[id]_route_actions_04w-53p.js")
R.m(421170)
module.exports=R.m(421170).exports
