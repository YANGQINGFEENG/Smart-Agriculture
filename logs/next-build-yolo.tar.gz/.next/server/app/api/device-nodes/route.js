var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/device-nodes/route.js")
R.c("server/chunks/[root-of-the-server]__0v54829._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device-nodes_route_actions_10.5qhw.js")
R.m(86685)
module.exports=R.m(86685).exports
