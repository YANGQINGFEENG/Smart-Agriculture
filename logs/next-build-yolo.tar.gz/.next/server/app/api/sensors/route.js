var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sensors/route.js")
R.c("server/chunks/[root-of-the-server]__0c71k2z._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sensors_route_actions_0i_vtpu.js")
R.m(805775)
module.exports=R.m(805775).exports
