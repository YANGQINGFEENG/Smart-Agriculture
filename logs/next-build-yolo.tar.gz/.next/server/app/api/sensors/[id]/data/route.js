var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sensors/[id]/data/route.js")
R.c("server/chunks/[root-of-the-server]__0ac1cxg._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sensors_[id]_data_route_actions_0-n4alh.js")
R.m(769361)
module.exports=R.m(769361).exports
