var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sensors/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0fzoml1._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_sensors_[id]_route_actions_0ganc1h.js")
R.m(920174)
module.exports=R.m(920174).exports
