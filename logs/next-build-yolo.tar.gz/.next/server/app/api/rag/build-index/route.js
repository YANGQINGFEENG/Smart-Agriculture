var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rag/build-index/route.js")
R.c("server/chunks/[root-of-the-server]__06~ztta._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_rag_build-index_route_actions_0vocz81.js")
R.m(411346)
module.exports=R.m(411346).exports
