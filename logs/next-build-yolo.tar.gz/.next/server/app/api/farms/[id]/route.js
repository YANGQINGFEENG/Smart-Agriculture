var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/farms/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0dzq_rv._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_farms_[id]_route_actions_0ksv450.js")
R.m(626531)
module.exports=R.m(626531).exports
