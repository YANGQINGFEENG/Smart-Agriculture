var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/farms/[id]/zones/route.js")
R.c("server/chunks/[root-of-the-server]__06b66k4._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_farms_[id]_zones_route_actions_0az87jl.js")
R.m(919724)
module.exports=R.m(919724).exports
