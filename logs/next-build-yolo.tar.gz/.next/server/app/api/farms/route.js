var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/farms/route.js")
R.c("server/chunks/[root-of-the-server]__01ojqzk._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_farms_route_actions_0cv6cpp.js")
R.m(478211)
module.exports=R.m(478211).exports
