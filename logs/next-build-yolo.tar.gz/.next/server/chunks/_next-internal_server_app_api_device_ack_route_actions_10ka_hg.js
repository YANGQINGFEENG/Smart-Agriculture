module.exports=[980098,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_device_ack_route_actions_10ka_hg.js.map