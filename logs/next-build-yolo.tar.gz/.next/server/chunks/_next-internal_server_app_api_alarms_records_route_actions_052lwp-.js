module.exports=[698861,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_alarms_records_route_actions_052lwp-.js.map