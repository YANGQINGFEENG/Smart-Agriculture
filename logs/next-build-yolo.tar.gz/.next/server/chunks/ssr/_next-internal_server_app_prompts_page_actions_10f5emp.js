module.exports=[330930,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_prompts_page_actions_10f5emp.js.map