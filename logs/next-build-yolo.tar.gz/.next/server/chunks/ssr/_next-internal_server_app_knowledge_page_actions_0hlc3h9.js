module.exports=[554709,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_knowledge_page_actions_0hlc3h9.js.map