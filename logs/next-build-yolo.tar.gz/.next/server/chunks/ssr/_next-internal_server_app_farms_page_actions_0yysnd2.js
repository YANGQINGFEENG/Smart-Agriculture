module.exports=[981602,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_farms_page_actions_0yysnd2.js.map