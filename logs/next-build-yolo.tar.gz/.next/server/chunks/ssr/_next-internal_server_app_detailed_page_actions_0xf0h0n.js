module.exports=[813289,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_detailed_page_actions_0xf0h0n.js.map