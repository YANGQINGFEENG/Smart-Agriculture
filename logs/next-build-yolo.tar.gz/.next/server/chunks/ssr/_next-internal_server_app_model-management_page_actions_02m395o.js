module.exports=[423256,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_model-management_page_actions_02m395o.js.map