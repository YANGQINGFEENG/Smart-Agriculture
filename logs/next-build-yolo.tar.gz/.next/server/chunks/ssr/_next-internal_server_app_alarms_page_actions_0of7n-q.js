module.exports=[556283,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_alarms_page_actions_0of7n-q.js.map