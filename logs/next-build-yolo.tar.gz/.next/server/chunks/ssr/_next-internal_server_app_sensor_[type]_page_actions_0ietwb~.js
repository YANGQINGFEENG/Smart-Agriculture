module.exports=[352913,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_sensor_%5Btype%5D_page_actions_0ietwb~.js.map