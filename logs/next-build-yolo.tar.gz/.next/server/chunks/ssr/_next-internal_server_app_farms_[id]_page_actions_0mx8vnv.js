module.exports=[525831,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_farms_%5Bid%5D_page_actions_0mx8vnv.js.map