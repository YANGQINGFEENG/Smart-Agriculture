module.exports=[319758,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_yolo-models_page_actions_0p67nre.js.map