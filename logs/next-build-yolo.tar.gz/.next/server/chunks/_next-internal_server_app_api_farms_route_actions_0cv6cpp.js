module.exports=[722136,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_farms_route_actions_0cv6cpp.js.map