module.exports=[625791,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_diagnosis_route_actions_11vn5lc.js.map