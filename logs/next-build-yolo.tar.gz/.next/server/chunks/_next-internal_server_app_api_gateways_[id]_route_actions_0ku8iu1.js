module.exports=[606047,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gateways_%5Bid%5D_route_actions_0ku8iu1.js.map