module.exports=[991490,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_zones_%5Bid%5D_route_actions_0o4zu7m.js.map