module.exports=[689949,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_knowledge_compare_route_actions_0khrlxw.js.map