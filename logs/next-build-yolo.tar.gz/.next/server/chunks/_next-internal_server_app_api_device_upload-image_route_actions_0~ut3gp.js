module.exports=[561181,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_device_upload-image_route_actions_0~ut3gp.js.map