module.exports=[387980,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_device_heartbeat_route_actions_05c_01g.js.map