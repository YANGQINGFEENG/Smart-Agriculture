module.exports=[169841,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sensors_%5Bid%5D_data_route_actions_0-n4alh.js.map