module.exports=[875700,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sensor-types_%5Bid%5D_route_actions_0v7_c8v.js.map