module.exports=[347522,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_image-recognition_route_actions_0rq05~r.js.map