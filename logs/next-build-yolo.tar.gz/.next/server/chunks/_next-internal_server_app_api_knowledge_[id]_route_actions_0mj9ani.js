module.exports=[507565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_knowledge_%5Bid%5D_route_actions_0mj9ani.js.map