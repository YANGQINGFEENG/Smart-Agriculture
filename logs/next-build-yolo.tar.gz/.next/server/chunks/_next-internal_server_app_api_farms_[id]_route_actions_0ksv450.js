module.exports=[402919,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_farms_%5Bid%5D_route_actions_0ksv450.js.map