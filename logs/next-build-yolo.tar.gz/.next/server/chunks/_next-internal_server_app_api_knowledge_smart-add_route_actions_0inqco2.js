module.exports=[467650,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_knowledge_smart-add_route_actions_0inqco2.js.map