module.exports=[92895,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_farms_%5Bid%5D_zones_route_actions_0az87jl.js.map