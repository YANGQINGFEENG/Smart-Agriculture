module.exports=[148959,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sensor-types_route_actions_0250656.js.map