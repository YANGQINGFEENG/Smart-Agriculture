module.exports=[320902,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sensors_route_actions_0i_vtpu.js.map