module.exports=[668759,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_device_yolo-models_switch_route_actions_0v37-tb.js.map