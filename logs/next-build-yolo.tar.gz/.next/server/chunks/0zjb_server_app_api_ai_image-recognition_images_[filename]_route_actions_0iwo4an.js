module.exports=[366739,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_ai_image-recognition_images_%5Bfilename%5D_route_actions_0iwo4an.js.map