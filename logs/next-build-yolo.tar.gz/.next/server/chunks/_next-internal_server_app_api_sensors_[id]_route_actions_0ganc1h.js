module.exports=[916121,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sensors_%5Bid%5D_route_actions_0ganc1h.js.map