module.exports=[99089,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_check-sensors_route_actions_0enwk8~.js.map