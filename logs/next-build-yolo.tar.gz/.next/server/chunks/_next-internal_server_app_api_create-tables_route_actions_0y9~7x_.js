module.exports=[259756,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_create-tables_route_actions_0y9~7x_.js.map