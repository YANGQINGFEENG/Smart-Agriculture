module.exports=[865770,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_check-tables_route_actions_00a66xw.js.map