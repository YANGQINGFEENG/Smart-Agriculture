/**
 * @file    4G_Module.h
 * @brief   4G模块驱动头文件
 * @details 实现4G模块的初始化和通信功能，使用USART1（PA11/PA12）
 * @author  Smart Agriculture Team
 * @date    2026-04-18
 * @version 1.0.0
 * @note    USART1重映射到PA11/PA12，4G模块通信使用115200波特率
 */

#ifndef __4G_MODULE_H
#define __4G_MODULE_H

#include "stm32f10x.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/* ==================== 4G模块引脚定义 ==================== */

/* 4G模块控制引脚定义 */
#define G4G_STATUS_GPIO_PORT             GPIOB
#define G4G_STATUS_GPIO_PIN              GPIO_Pin_4
#define G4G_STATUS_GPIO_CLK              RCC_APB2Periph_GPIOB

/* 4G模块状态检测 */
#define G4G_GET_STATUS                   GPIO_ReadInputDataBit(G4G_STATUS_GPIO_PORT, G4G_STATUS_GPIO_PIN)

/* ==================== USART1重映射配置 ==================== */

/* USART1重映射到PA11/PA12：
 * - USART1_TX = PA12 (重映射)
 * - USART1_RX = PA11 (重映射)
 */
#define G4G_USART                          USART1
#define G4G_USART_CLK                      RCC_APB2Periph_USART1
#define G4G_USART_BAUD_RATE                115200

/* 重映射后的GPIO配置 */
#define G4G_USART_TX_GPIO_PORT             GPIOA
#define G4G_USART_TX_GPIO_PIN              GPIO_Pin_12
#define G4G_USART_TX_GPIO_CLK              RCC_APB2Periph_GPIOA

#define G4G_USART_RX_GPIO_PORT             GPIOA
#define G4G_USART_RX_GPIO_PIN              GPIO_Pin_11
#define G4G_USART_RX_GPIO_CLK              RCC_APB2Periph_GPIOA

/* USART1中断配置 */
#define G4G_USART_IRQn                     USART1_IRQn
#define G4G_USART_CLK_ENABLE()               RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE)

/* ==================== 接收缓冲区配置 ==================== */

#define G4G_USART_RX_BUF_SIZE             256         /* 接收缓冲区大小 */
#define G4G_USART_TX_BUF_SIZE             256         /* 发送缓冲区大小 */

/* ==================== 错误码定义 ==================== */

#define G4G_EOK           0x00              /* 没有错误 */
#define G4G_ERROR         0x01              /* 通用错误 */
#define G4G_ETIMEOUT      0x02              /* 超时错误 */
#define G4G_EBUSY         0x03              /* 设备忙 */

/* ==================== 函数声明 ==================== */

/**
 * @brief   4G模块初始化
 * @details 初始化4G模块的电源键引脚、状态检测引脚和USART1通信接口
 * @return  初始化结果
 * @retval  0: 成功
 * @retval  非0: 失败
 */
uint8_t G4G_Init(void);

/**
 * @brief   4G模块发送AT指令
 * @param   cmd AT指令字符串
 * @param   ack 期望的应答字符串
 * @param   timeout 超时时间（毫秒）
 * @return  执行结果
 * @retval  G4G_EOK: 成功收到应答
 * @retval  G4G_ETIMEOUT: 超时
 * @retval  G4G_ERROR: 收到错误应答
 */
uint8_t G4G_SendATCmd(char *cmd, char *ack, uint32_t timeout);

/**
 * @brief   4G模块发送数据
 * @param   data 数据指针
 * @param   size 数据大小
 * @return  发送结果
 * @retval  G4G_EOK: 成功
 * @retval  G4G_ERROR: 失败
 */
uint8_t G4G_SendData(uint8_t *data, uint32_t size);

/**
 * @brief   4G模块发送字符串
 * @param   str 字符串指针
 * @return  发送结果
 * @retval  G4G_EOK: 成功
 * @retval  G4G_ERROR: 失败
 */
uint8_t G4G_SendString(char *str);

/**
 * @brief   获取4G模块接收到的数据
 * @return  接收到的数据指针，如果没有数据返回NULL
 */
char* G4G_GetRecvData(void);

/**
 * @brief   清除4G模块接收缓冲区
 * @return  无
 */
void G4G_ClearRecvBuf(void);

/**
 * @brief   检查4G模块状态
 * @return  模块状态
 * @retval  1: 模块已连接
 * @retval  0: 模块未连接或未上电
 */
uint8_t G4G_CheckStatus(void);

/**
 * @brief   4G模块 printf函数支持
 * @param   format 格式化字符串
 * @param   ... 可变参数
 * @return  发送的字符数
 */
int G4G_Printf(const char *format, ...);

#endif /* __4G_MODULE_H */