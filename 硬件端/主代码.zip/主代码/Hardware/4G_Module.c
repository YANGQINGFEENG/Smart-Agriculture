/**
 * @file    4G_Module.c
 * @brief   4G模块驱动实现文件
 * @details 实现4G模块的初始化和通信功能，使用USART1（PA11/PA12）
 * @author  Smart Agriculture Team
 * @date    2026-04-18
 * @version 1.0.0
 * @note    USART1重映射到PA11/PA12，4G模块通信使用115200波特率
 */

#include "4G_Module.h"
#include "../System/delay.h"
#include <stdarg.h>

/* ==================== 全局变量定义 ==================== */

/* USART1接收缓冲区 */
static uint8_t g4g_rx_buf[G4G_USART_RX_BUF_SIZE];
static uint16_t g4g_rx_len = 0;
static uint8_t g4g_rx_overflow = 0;

/* USART1发送缓冲区 */
static uint8_t g4g_tx_buf[G4G_USART_TX_BUF_SIZE];

/* 接收完成标志 */
static volatile uint8_t g4g_rx_complete = 0;

/**
 * @brief   初始化4G模块的GPIO
 * @details 初始化状态检测引脚
 * @return  无
 */
static void G4G_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(G4G_STATUS_GPIO_CLK, ENABLE);

    /* 初始化状态检测引脚 (PB4) - 浮空输入 */
    GPIO_InitStructure.GPIO_Pin = G4G_STATUS_GPIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(G4G_STATUS_GPIO_PORT, &GPIO_InitStructure);
}

/**
 * @brief   初始化USART1（重映射到PA11/PA12）
 * @details 配置USART1的GPIO为复用功能
 * @return  无
 */
static void G4G_USART_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;

    /* 使能GPIOA和USART1时钟 */
    RCC_APB2PeriphClockCmd(G4G_USART_TX_GPIO_CLK | G4G_USART_RX_GPIO_CLK | G4G_USART_CLK | RCC_APB2Periph_AFIO, ENABLE);

    /* 使能USART1重映射 (PA11/PA12) */
    GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);

    /* 配置USART1_TX (PA12) - 复用推挽输出 */
    GPIO_InitStructure.GPIO_Pin = G4G_USART_TX_GPIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(G4G_USART_TX_GPIO_PORT, &GPIO_InitStructure);

    /* 配置USART1_RX (PA11) - 浮空输入 */
    GPIO_InitStructure.GPIO_Pin = G4G_USART_RX_GPIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(G4G_USART_RX_GPIO_PORT, &GPIO_InitStructure);

    /* 配置USART1 */
    USART_InitStructure.USART_BaudRate = G4G_USART_BAUD_RATE;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART1, &USART_InitStructure);

    /* 使能USART1 */
    USART_Cmd(USART1, ENABLE);
}

/* ==================== 函数实现 ==================== */

/**
 * @brief   4G模块初始化
 * @details 初始化4G模块的电源键引脚、状态检测引脚和USART1通信接口
 * @return  初始化结果
 * @retval  0: 成功
 * @retval  非0: 失败
 */
uint8_t G4G_Init(void)
{
    /* 初始化GPIO */
    G4G_GPIO_Init();

    /* 初始化USART1 */
    G4G_USART_Init();

    /* 清除接收缓冲区 */
    G4G_ClearRecvBuf();

    return 0;
}

/**
 * @brief   4G模块发送AT指令
 * @param   cmd AT指令字符串
 * @param   ack 期望的应答字符串
 * @param   timeout 超时时间（毫秒）
 * @return  执行结果
 * @retval  G4G_EOK: 成功收到应答
 * @retval  G4G_ETIMEOUT: 超时
 * @retval  G4G_ERROR: 收到错误应答
 */
uint8_t G4G_SendATCmd(char *cmd, char *ack, uint32_t timeout)
{
    uint32_t tick_start;
    char *p;

    G4G_ClearRecvBuf();

    G4G_Printf("%s\r\n", cmd);

    if (ack == NULL || timeout == 0)
    {
        return G4G_EOK;
    }

    tick_start = 0;
    while (1)
    {
        if (tick_start >= timeout)
        {
            return G4G_ETIMEOUT;
        }

        /* 轮询接收数据 */
        while (USART_GetFlagStatus(G4G_USART, USART_FLAG_RXNE) != RESET)
        {
            if (g4g_rx_len < G4G_USART_RX_BUF_SIZE)
            {
                g4g_rx_buf[g4g_rx_len++] = USART_ReceiveData(G4G_USART);
                g4g_rx_complete = 1;
            }
            else
            {
                g4g_rx_overflow = 1;
                USART_ReceiveData(G4G_USART); // 清除接收标志
            }
        }

        if (g4g_rx_complete)
        {
            g4g_rx_buf[g4g_rx_len] = '\0';
            p = strstr((char *)g4g_rx_buf, ack);
            if (p != NULL)
            {
                return G4G_EOK;
            }

            if (strstr((char *)g4g_rx_buf, "ERROR") != NULL)
            {
                return G4G_ERROR;
            }

            g4g_rx_complete = 0;
        }

        Delay_ms(10);
        tick_start += 10;
    }
}

/**
 * @brief   4G模块发送数据
 * @param   data 数据指针
 * @param   size 数据长度
 * @return  发送结果
 * @retval  0: 成功
 * @retval  非0: 失败
 */
uint8_t G4G_SendData(uint8_t *data, uint32_t size)
{
    uint32_t i;

    for (i = 0; i < size; i++)
    {
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
        USART_SendData(USART1, data[i]);
    }

    return 0;
}

/**
 * @brief   4G模块发送字符串
 * @param   str 字符串指针
 * @return  发送结果
 * @retval  0: 成功
 * @retval  非0: 失败
 */
uint8_t G4G_SendString(char *str)
{
    return G4G_SendData((uint8_t *)str, strlen(str));
}

/**
 * @brief   获取4G模块接收到的数据
 * @return  接收到的数据指针，如果没有数据返回NULL
 */
char* G4G_GetRecvData(void)
{
    if (g4g_rx_len > 0)
    {
        g4g_rx_buf[g4g_rx_len] = '\0';
        return (char *)g4g_rx_buf;
    }
    return NULL;
}

/**
 * @brief   清除4G模块接收缓冲区
 * @return  无
 */
void G4G_ClearRecvBuf(void)
{
    uint16_t i;
    for (i = 0; i < G4G_USART_RX_BUF_SIZE; i++)
    {
        g4g_rx_buf[i] = 0;
    }
    g4g_rx_len = 0;
    g4g_rx_complete = 0;
    g4g_rx_overflow = 0;
}

/**
 * @brief   检查4G模块状态
 * @return  模块状态
 * @retval  1: 模块已连接
 * @retval  0: 模块未连接或未上电
 */
uint8_t G4G_CheckStatus(void)
{
    return G4G_GET_STATUS;
}

/**
 * @brief   4G模块 printf函数支持
 * @param   format 格式化字符串
 * @param   ... 可变参数
 * @return  发送的字符数
 */
int G4G_Printf(const char *format, ...)
{
    va_list arg;
    uint16_t len;
    int result;

    va_start(arg, format);
    len = vsnprintf((char *)g4g_tx_buf, G4G_USART_TX_BUF_SIZE, format, arg);
    va_end(arg);

    result = G4G_SendData(g4g_tx_buf, len);

    return result == 0 ? len : result;
}
