var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check-tables/route.js")
R.c("server/chunks/[root-of-the-server]__0kbtkqy._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_check-tables_route_actions_00a66xw.js")
R.m(339660)
module.exports=R.m(339660).exports
