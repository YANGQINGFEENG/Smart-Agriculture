var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/check-sensors/route.js")
R.c("server/chunks/[root-of-the-server]__0_~2q_a._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_check-sensors_route_actions_0enwk8~.js")
R.m(384287)
module.exports=R.m(384287).exports
