var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create-tables/route.js")
R.c("server/chunks/[root-of-the-server]__0~dnkhc._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_create-tables_route_actions_0y9~7x_.js")
R.m(55695)
module.exports=R.m(55695).exports
