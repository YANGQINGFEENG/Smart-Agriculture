var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alarms/rules/route.js")
R.c("server/chunks/[root-of-the-server]__0xcm4_l._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_alarms_rules_route_actions_0tovbe8.js")
R.m(784326)
module.exports=R.m(784326).exports
