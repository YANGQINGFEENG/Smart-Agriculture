var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alarms/records/route.js")
R.c("server/chunks/[root-of-the-server]__08m5h6p._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_alarms_records_route_actions_052lwp-.js")
R.m(739584)
module.exports=R.m(739584).exports
