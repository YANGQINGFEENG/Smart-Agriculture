var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/models/route.js")
R.c("server/chunks/[root-of-the-server]__0~71mmj._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_models_route_actions_0icm40g.js")
R.m(387100)
module.exports=R.m(387100).exports
