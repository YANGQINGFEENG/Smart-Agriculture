var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/heartbeat/route.js")
R.c("server/chunks/[root-of-the-server]__0h5m-di._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device_heartbeat_route_actions_05c_01g.js")
R.m(836781)
module.exports=R.m(836781).exports
