var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/report/route.js")
R.c("server/chunks/[root-of-the-server]__00lsqmf._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0bjtc9c.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/_next-internal_server_app_api_device_report_route_actions_0c_fjr_.js")
R.m(718503)
module.exports=R.m(718503).exports
