var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/ack/route.js")
R.c("server/chunks/[root-of-the-server]__0_7pq2o._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0s94dmq.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device_ack_route_actions_10ka_hg.js")
R.m(519574)
module.exports=R.m(519574).exports
