var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/agent-diagnosis/route.js")
R.c("server/chunks/[root-of-the-server]__0nkj01p._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device_agent-diagnosis_route_actions_0~_nkt-.js")
R.m(315907)
module.exports=R.m(315907).exports
