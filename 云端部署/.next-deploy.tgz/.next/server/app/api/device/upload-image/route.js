var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/device/upload-image/route.js")
R.c("server/chunks/[root-of-the-server]__0v6_v4u._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_device_upload-image_route_actions_0~ut3gp.js")
R.m(171855)
module.exports=R.m(171855).exports
