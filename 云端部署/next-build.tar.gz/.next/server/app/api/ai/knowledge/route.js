var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/knowledge/route.js")
R.c("server/chunks/[root-of-the-server]__03awv9y._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_knowledge_route_actions_0lat-f4.js")
R.m(417878)
module.exports=R.m(417878).exports
