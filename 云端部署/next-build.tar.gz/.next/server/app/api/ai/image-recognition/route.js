var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/image-recognition/route.js")
R.c("server/chunks/[root-of-the-server]__03h0vgt._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_image-recognition_route_actions_0rq05~r.js")
R.m(249268)
module.exports=R.m(249268).exports
