var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/image-recognition/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0r6052i._.js")
R.c("server/chunks/[root-of-the-server]__0n31n7c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_image-recognition_[id]_route_actions_04a1be1.js")
R.m(555396)
module.exports=R.m(555396).exports
